-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2020 at 07:08 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fmcourier`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `name` varchar(30) NOT NULL,
  `mobileoremail` varchar(20) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `orderno` varchar(6) DEFAULT NULL,
  `amount` int(11) NOT NULL,
  `ssubagentid` int(11) NOT NULL,
  `ssubagentamount` int(11) NOT NULL,
  `sdistagentid` int(11) NOT NULL,
  `sdistagentamount` int(11) NOT NULL,
  `sdivagentid` int(11) NOT NULL,
  `sdivagentamount` int(11) NOT NULL,
  `rsubagentid` int(11) NOT NULL,
  `rsubagentamount` int(11) NOT NULL,
  `rdistagentid` int(11) NOT NULL,
  `rdistagentamount` int(11) NOT NULL,
  `rdivagentid` int(11) NOT NULL,
  `rdivagentamount` int(11) NOT NULL,
  `adminamount` int(11) NOT NULL,
  `verification` tinyint(1) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `orderno`, `amount`, `ssubagentid`, `ssubagentamount`, `sdistagentid`, `sdistagentamount`, `sdivagentid`, `sdivagentamount`, `rsubagentid`, `rsubagentamount`, `rdistagentid`, `rdistagentamount`, `rdivagentid`, `rdivagentamount`, `adminamount`, `verification`, `updated_at`, `created_at`) VALUES
(1, '1', 100, 2, 15, 1, 10, 1, 5, 5, 15, 2, 10, 2, 5, 40, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `accounts2`
--

CREATE TABLE `accounts2` (
  `id` int(11) NOT NULL,
  `orderno` varchar(6) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `ssubagentid` int(11) DEFAULT NULL,
  `ssubagentamount` int(11) DEFAULT NULL,
  `sdistagentid` int(11) DEFAULT NULL,
  `sdistagentamount` int(11) DEFAULT NULL,
  `sdivagentid` int(11) DEFAULT NULL,
  `sdivagentamount` int(11) DEFAULT NULL,
  `rsubagentid` int(11) DEFAULT NULL,
  `rsubagentamount` int(11) DEFAULT NULL,
  `rdistagentid` int(11) DEFAULT NULL,
  `rdistagentamount` int(11) DEFAULT NULL,
  `rdivagentid` int(11) DEFAULT NULL,
  `rdivagentamount` int(11) DEFAULT NULL,
  `adminamount` int(11) DEFAULT NULL,
  `verification` tinyint(1) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `agentlatest`
--

CREATE TABLE `agentlatest` (
  `id` int(7) NOT NULL,
  `name` varchar(50) NOT NULL,
  `fathername` varchar(50) NOT NULL,
  `mothername` varchar(50) NOT NULL,
  `mobilenumber` varchar(15) NOT NULL,
  `requestmobile` varchar(15) NOT NULL,
  `shopaddress` varchar(200) NOT NULL,
  `permanentaddress` varchar(200) NOT NULL,
  `code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `agentlatest`
--

INSERT INTO `agentlatest` (`id`, `name`, `fathername`, `mothername`, `mobilenumber`, `requestmobile`, `shopaddress`, `permanentaddress`, `code`) VALUES
(1, 'shamim reza', 's', 's', '01615112358', '01615112358', 'AK Center, 3rd Floor, CDA Avenue, East Nasirabad,', 'AK Center, 3rd Floor, CDA Avenue, East Nasirabad,', '123');

-- --------------------------------------------------------

--
-- Table structure for table `agentreceives`
--

CREATE TABLE `agentreceives` (
  `id` int(6) NOT NULL,
  `orderid` varchar(10) NOT NULL,
  `subagentid` int(6) NOT NULL,
  `trackingchange` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `agentreceives`
--

INSERT INTO `agentreceives` (`id`, `orderid`, `subagentid`, `trackingchange`) VALUES
(1, '1', 5, 'recieved final');

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `agentcode` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`id`, `name`, `address`, `mobile`, `agentcode`) VALUES
(1, 'shamim', 'gec', '01922414121', '123');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `mobileoremail` varchar(30) NOT NULL,
  `description` varchar(200) NOT NULL,
  `category` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `name`, `mobileoremail`, `description`, `category`) VALUES
(1, 'shamim', '0155341', 'jssjggs', 'main');

-- --------------------------------------------------------

--
-- Table structure for table `distagents`
--

CREATE TABLE `distagents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `division` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postalcode` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `divagentcode` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `distagents`
--

INSERT INTO `distagents` (`id`, `code`, `name`, `mobile`, `address`, `division`, `district`, `postalcode`, `divagentcode`, `created_at`, `updated_at`) VALUES
(0, '1', 'reza', '01615112358', 'cda', 'khulna', 'bagerhat', '1234', '1', '2020-10-20 18:00:00', '2020-10-20 18:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `distrecieves`
--

CREATE TABLE `distrecieves` (
  `id` int(11) NOT NULL,
  `orderid` varchar(10) NOT NULL,
  `distagentid` int(6) NOT NULL,
  `trackingchange` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `distrecieves`
--

INSERT INTO `distrecieves` (`id`, `orderid`, `distagentid`, `trackingchange`) VALUES
(1, '1', 1, 'district recieve');

-- --------------------------------------------------------

--
-- Table structure for table `divagents`
--

CREATE TABLE `divagents` (
  `id` int(5) NOT NULL,
  `code` varchar(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `address` varchar(100) NOT NULL,
  `postalcode` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `divagents`
--

INSERT INTO `divagents` (`id`, `code`, `name`, `mobile`, `address`, `postalcode`) VALUES
(1, '1', 'xyz', '01922414121', 'abcd', 1234);

-- --------------------------------------------------------

--
-- Table structure for table `divreceives`
--

CREATE TABLE `divreceives` (
  `id` int(11) NOT NULL,
  `orderid` varchar(10) NOT NULL,
  `code` varchar(6) NOT NULL,
  `status` varchar(20) NOT NULL,
  `deliverydetails` varchar(30) NOT NULL,
  `trackingchange` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `divreceives`
--

INSERT INTO `divreceives` (`id`, `orderid`, `code`, `status`, `deliverydetails`, `trackingchange`) VALUES
(1, '1', '1', 'shg@sdf', '100', 'division recieves'),
(2, '1', '23', 'subagent', 'div for dist', 'div for dist');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `position` varchar(50) NOT NULL,
  `mobilenumber` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`id`, `name`, `position`, `mobilenumber`) VALUES
(1, 'shamim', 'member', '0975');

-- --------------------------------------------------------

--
-- Table structure for table `merchants`
--

CREATE TABLE `merchants` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buisnesstype` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `producttype` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thana` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pickupaddress` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weblink` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fblink` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `personname` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `personstatus` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactnumber` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `paymentmethod` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accountname` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accountnumber` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `merchants`
--

INSERT INTO `merchants` (`id`, `name`, `buisnesstype`, `producttype`, `address`, `district`, `thana`, `pickupaddress`, `weblink`, `fblink`, `mobile`, `personname`, `personstatus`, `contactnumber`, `email`, `paymentmethod`, `accountname`, `accountnumber`, `created_at`, `updated_at`) VALUES
(1, 'shamim reza', 'a', 'a', 'AK Center, 3rd Floor, CDA Avenue, East Nasirabad,', 'a', 'a', 'AK Center, 3rd Floor, CDA Avenue, East Nasirabad,', 'a', 'a', '01615112358', 'a', 'a', 'lastone', 'admin@admin.com', 'a', 'a', 'a', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_100000_create_password_resets_table', 1),
(2, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(3, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(4, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(5, '2016_06_01_000004_create_oauth_clients_table', 1),
(6, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(7, '2019_09_10_000000_create_permissions_table', 1),
(8, '2019_09_10_000001_create_roles_table', 1),
(9, '2019_09_10_000002_create_users_table', 1),
(10, '2019_09_10_000003_create_permission_role_pivot_table', 1),
(11, '2019_09_10_000004_create_role_user_pivot_table', 1),
(12, '2020_10_13_083544_create_tenteches_table', 2),
(13, '2020_10_14_110420_create_subagents_table', 2),
(14, '2020_10_15_094139_create_sending_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `name`
--

CREATE TABLE `name` (
  `name` varchar(20) NOT NULL,
  `age` int(11) NOT NULL,
  `childage` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `name`
--

INSERT INTO `name` (`name`, `age`, `childage`, `updated_at`, `created_at`) VALUES
('shamim reza', 0, 0, NULL, NULL),
('jewl reza', 0, 0, NULL, NULL),
('shamim', 29, 10, NULL, NULL),
('reza', 15, 10, '2020-10-21 10:28:15', '2020-10-21 10:28:15'),
('reza', 15, 5, '2020-10-21 10:30:00', '2020-10-21 10:30:00'),
('reza', 15, 75, '2020-10-21 11:19:36', '2020-10-21 11:19:36'),
('reza', 5, 2, '2020-10-21 11:20:45', '2020-10-21 11:20:45'),
('reza', 5, 2, '2020-10-21 22:03:02', '2020-10-21 22:03:02');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `title`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'permission_create', '2019-09-10 08:00:26', '2019-09-10 08:00:26', NULL),
(2, 'permission_edit', '2019-09-10 08:00:26', '2019-09-10 08:00:26', NULL),
(3, 'permission_show', '2019-09-10 08:00:26', '2019-09-10 08:00:26', NULL),
(4, 'permission_delete', '2019-09-10 08:00:26', '2019-09-10 08:00:26', NULL),
(5, 'permission_access', '2019-09-10 08:00:26', '2019-09-10 08:00:26', NULL),
(6, 'role_create', '2019-09-10 08:00:26', '2019-09-10 08:00:26', NULL),
(7, 'role_edit', '2019-09-10 08:00:26', '2019-09-10 08:00:26', NULL),
(8, 'role_show', '2019-09-10 08:00:26', '2019-09-10 08:00:26', NULL),
(9, 'role_delete', '2019-09-10 08:00:26', '2019-09-10 08:00:26', NULL),
(10, 'role_access', '2019-09-10 08:00:26', '2019-09-10 08:00:26', NULL),
(11, 'user_management_access', '2019-09-10 08:00:26', '2019-09-10 08:00:26', NULL),
(12, 'user_create', '2019-09-10 08:00:26', '2019-09-10 08:00:26', NULL),
(13, 'user_edit', '2019-09-10 08:00:26', '2019-09-10 08:00:26', NULL),
(14, 'user_show', '2019-09-10 08:00:26', '2019-09-10 08:00:26', NULL),
(15, 'user_delete', '2019-09-10 08:00:26', '2019-09-10 08:00:26', NULL),
(16, 'user_access', '2019-09-10 08:00:26', '2019-09-10 08:00:26', NULL),
(17, 'tentech_access', '2020-10-13 02:51:44', '2020-10-13 02:51:44', NULL),
(18, 'tentech-menu', '2020-10-13 03:00:28', '2020-10-13 03:00:28', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE `permission_role` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `permission_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`role_id`, `permission_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(1, 9),
(1, 10),
(1, 11),
(1, 12),
(1, 13),
(1, 14),
(1, 15),
(1, 16),
(1, 17),
(2, 18),
(3, 3),
(4, 1),
(5, 1),
(6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `title`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Admin', '2019-09-10 08:00:26', '2019-09-10 08:00:26', NULL),
(2, 'User', '2019-09-10 08:00:26', '2019-09-10 08:00:26', NULL),
(3, 'subagent', '2020-10-17 02:27:24', '2020-10-17 02:27:24', NULL),
(4, 'agent', '2020-10-22 05:40:36', '2020-10-22 05:40:36', NULL),
(5, 'divisional agent', '2020-10-22 05:41:08', '2020-10-22 05:41:08', NULL),
(6, 'employee', '2020-10-22 05:41:22', '2020-10-22 05:41:22', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`user_id`, `role_id`) VALUES
(1, 1),
(2, 2),
(2, 3),
(3, 4);

-- --------------------------------------------------------

--
-- Table structure for table `sendings`
--

CREATE TABLE `sendings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `orderid` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int(8) NOT NULL,
  `frompostalcode` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mycode` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sendpostalcode` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `division` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subagentamount` int(11) NOT NULL,
  `distagentamount` int(11) NOT NULL,
  `divagentamount` int(11) NOT NULL,
  `adminamount` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sendings`
--

INSERT INTO `sendings` (`id`, `orderid`, `code`, `amount`, `frompostalcode`, `mycode`, `address`, `sendpostalcode`, `division`, `district`, `subagentamount`, `distagentamount`, `divagentamount`, `adminamount`, `created_at`, `updated_at`) VALUES
(1, '1', '2', 100, '2314', '5', 'hfydtrsete', '2341', 'khulna', 'chattogram', 15, 10, 5, 40, '2020-10-20 18:00:00', '2020-10-20 18:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `subagents`
--

CREATE TABLE `subagents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `division` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postalcode` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `disagentcode` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `divagentcode` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subagents`
--

INSERT INTO `subagents` (`id`, `code`, `name`, `status`, `mobile`, `address`, `division`, `district`, `postalcode`, `disagentcode`, `divagentcode`, `created_at`, `updated_at`) VALUES
(1, '12', 'shamim reza', '', '01615112358', 'AK Center, 3rd Floor, CDA Avenue, East Nasirabad,', 'khulna', 'bagerhat', '4217', '1', '', NULL, NULL),
(2, '13', 'shamims rezas', '', '01615112358', 'AK Center, 3rd Floor, CDA Avenue, East Nasirabad,', 'chattogram', 'chattogram', '4217', '1', '', NULL, NULL),
(3, '13', 'reza', '', '01615112358', 'AK Center, 3rd Floor, CDA Avenue, East Nasirabad,', 'chattogram', 'chattogram', '4217', '1', '', NULL, NULL),
(4, '15', 'xyz', '', '01615112358', 'AK Center, 3rd Floor, CDA Avenue, East Nasirabad,', 'chattogram', 'chattogram', '4217', '1', '', NULL, NULL),
(5, '15', 'reza xyz', '', '01615112358', 'AK Center, 3rd Floor, CDA Avenue, East Nasirabad,', 'chattogram', 'chattogram', '4217', '1', '', NULL, NULL),
(6, '', 'shamim reza', '', '01615112358', 'AK Center, 3rd Floor, CDA Avenue, East Nasirabad,', 'khulna', 'chattogram', '4217', '1', '', NULL, NULL),
(7, '', 'reza shamim reza', '', '01615112358', 'AK Center, 3rd Floor, CDA Avenue, East Nasirabad,', 'khulna', 'chattogram', '4217', '1', '', NULL, NULL),
(8, '18', 'shamim reza', '', '01615112358', 'AK Center, 3rd Floor, CDA Avenue, East Nasirabad,', 'khulna', 'chattogram', '4217', '1', '', NULL, NULL),
(9, '722148', 'shamim reza', '', '01615112358', 'AK Center, 3rd Floor, CDA Avenue, East Nasirabad,', 'khulna', 'chattogram', '4217', '1', '', NULL, NULL),
(10, '12345', 'jewl reza', '', '01615112358', 'AK Center, 3rd Floor, CDA Avenue, East Nasirabad,', 'chattogram', 'chattogram', '4217', '2', '', NULL, NULL),
(11, '12', 'shamim reza', 'divagent', '01615112358', 'AK Center, 3rd Floor, CDA Avenue, East Nasirabad,', 'khulna', 'chattogram', '4217', '1', '2', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tenteches`
--

CREATE TABLE `tenteches` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Admin', 'admin@admin.com', NULL, '$2y$10$qyxYm.2dlaXROvs0OrGHseo4qbeissRMqNWdhlcr/vUqE62vN94Fi', NULL, '2019-09-10 08:00:26', '2019-09-10 08:00:26', NULL),
(2, 'tipu', 'tipu@gmail.com', NULL, '$2y$10$sOMb/ylifUP2DeJ7ZEnJe.M5pk8k63xbuney7Msk5x.He3figDlJy', NULL, '2020-10-13 02:58:29', '2020-10-13 02:58:29', NULL),
(3, 'jewel', 'ad@ad', NULL, '$2y$10$rRQ6Eu1TvrNLhVIh9LNMPeOcYSCggA22PvhI7ZdFumrC1eS88N/46', NULL, '2020-10-22 05:42:50', '2020-10-22 05:42:50', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `agentreceives`
--
ALTER TABLE `agentreceives`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `distrecieves`
--
ALTER TABLE `distrecieves`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `divagents`
--
ALTER TABLE `divagents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `divreceives`
--
ALTER TABLE `divreceives`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD KEY `role_id_fk_6744` (`role_id`),
  ADD KEY `permission_id_fk_6744` (`permission_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD KEY `user_id_fk_6753` (`user_id`),
  ADD KEY `role_id_fk_6753` (`role_id`);

--
-- Indexes for table `sendings`
--
ALTER TABLE `sendings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subagents`
--
ALTER TABLE `subagents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tenteches`
--
ALTER TABLE `tenteches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `agentreceives`
--
ALTER TABLE `agentreceives`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `distrecieves`
--
ALTER TABLE `distrecieves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `divagents`
--
ALTER TABLE `divagents`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `divreceives`
--
ALTER TABLE `divreceives`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sendings`
--
ALTER TABLE `sendings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `subagents`
--
ALTER TABLE `subagents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tenteches`
--
ALTER TABLE `tenteches`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_id_fk_6744` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_id_fk_6744` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_id_fk_6753` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_id_fk_6753` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
